# Mini Mall — Vercel-ready

This project includes:
- Public storefront
- Admin login at `/admin`
- Add / edit / delete products
- PostgreSQL-backed products
- Automatic database schema creation on first server request
- Automatic admin account creation/update from environment variables

## Required Vercel Environment Variables

Set these in Vercel before the first production request:

- `DATABASE_URL` — your PostgreSQL connection string
- `SESSION_SECRET` — a long random secret
- `ADMIN_EMAIL` — the email used to sign in to `/admin`
- `ADMIN_PASSWORD` — the password used to sign in to `/admin`

No manual `db.sql` command or `create-admin.mjs` command is required.

## Admin page

Open:

`/admin`

Use the exact `ADMIN_EMAIL` and `ADMIN_PASSWORD` from Vercel.

## Important

Do not commit a real `DATABASE_URL`, `SESSION_SECRET`, or real password to GitHub.
