export const runtime = "nodejs"

import { NextResponse } from "next/server"
import { makeSession, sessionCookie } from "@/lib/auth"
import { ensureAdminAccount, verifyAdminCredentials } from "@/lib/admin"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const email = String(body.email || "").trim()
    const password = String(body.password || "")

    if (!email || !password) {
      return NextResponse.json(
        { error: "البريد الإلكتروني وكلمة المرور مطلوبان" },
        { status: 400 },
      )
    }

    await ensureAdminAccount()

    const verifiedEmail = await verifyAdminCredentials(email, password)

    if (!verifiedEmail) {
      return NextResponse.json(
        { error: "البريد أو كلمة المرور غير صحيحة" },
        { status: 401 },
      )
    }

    const token = makeSession(verifiedEmail)
    const response = NextResponse.json({ ok: true })

    response.cookies.set({
      name: sessionCookie,
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    })

    return response
  } catch (error) {
    console.error("LOGIN_ERROR", error)
    return NextResponse.json(
      { error: "تعذر تسجيل الدخول. تأكد من إعداد قاعدة البيانات وبيانات المدير في Vercel." },
      { status: 500 },
    )
  }
}
