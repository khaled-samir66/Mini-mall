import bcrypt from "bcryptjs"
import { db, ensureSchema } from "@/lib/db"

export async function ensureAdminAccount() {
  await ensureSchema()

  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase()
  const password = String(process.env.ADMIN_PASSWORD || "")

  if (!email || !password) {
    throw new Error("ADMIN_EMAIL and ADMIN_PASSWORD are missing")
  }

  const hash = await bcrypt.hash(password, 12)

  await db.query(
    `INSERT INTO admins (email, password_hash)
     VALUES ($1, $2)
     ON CONFLICT (email)
     DO UPDATE SET password_hash = EXCLUDED.password_hash`,
    [email, hash],
  )

  return email
}

export async function verifyAdminCredentials(email: string, password: string) {
  await ensureSchema()

  const normalized = email.trim().toLowerCase()
  const result = await db.query(
    "SELECT email, password_hash FROM admins WHERE email = $1 LIMIT 1",
    [normalized],
  )

  const row = result.rows[0]
  if (!row) return null

  const valid = await bcrypt.compare(password, row.password_hash)
  return valid ? String(row.email) : null
}
