import { Pool } from "pg"

const globalForDb = globalThis as unknown as {
  pool?: Pool
  initPromise?: Promise<void>
}

export const db =
  globalForDb.pool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 5,
    ssl:
      process.env.NODE_ENV === "production"
        ? { rejectUnauthorized: false }
        : undefined,
  })

if (process.env.NODE_ENV !== "production") {
  globalForDb.pool = db
}

export async function ensureSchema() {
  if (!globalForDb.initPromise) {
    globalForDb.initPromise = (async () => {
      if (!process.env.DATABASE_URL) {
        throw new Error("DATABASE_URL is missing")
      }

      await db.query(`
        CREATE TABLE IF NOT EXISTS admins (
          id BIGSERIAL PRIMARY KEY,
          email VARCHAR(190) NOT NULL UNIQUE,
          password_hash VARCHAR(255) NOT NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS products (
          id BIGSERIAL PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          category VARCHAR(255) NOT NULL,
          price NUMERIC(10,2),
          old_price NUMERIC(10,2),
          description TEXT,
          image TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_products_category
          ON products(category);
      `)
    })().catch((error) => {
      globalForDb.initPromise = undefined
      throw error
    })
  }

  await globalForDb.initPromise
}
